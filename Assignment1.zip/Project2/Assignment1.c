//MuhannedHasan 2200000776
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdbool.h>

// Define a struct to represent a date with month, day, and year
struct date {
    int month;
    int day;
    int year;
};

// Function to check if a given year is a leap year
bool is_leap_year(struct date day) {
    if (day.year % 4 == 0) { // If the year is divisible by 4
        if (day.year % 100 == 0) { // If the year is also divisible by 100
            if (day.year % 400 == 0) { // If the year is divisible by 400
                return true; // Then it's a leap year
            }
            else {
                return false; // Otherwise, it's not a leap year
            }
        }
        else {
            return true; // If the year is not divisible by 100 but is divisible by 4, it's a leap year
        }
    }
    else {
        return false; // Otherwise, it's not a leap year
    }
}

// Function to calculate the date of the next day
struct date tomorrow(struct date day) {
    int days_in_month[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 }; // Array to store number of days in each month
    if (day.month == 12 && day.day == 31) { 
        // If it's the last day of the year
        day.month = 1; // Set the month to January
        day.day = 1; // Set the day to the first day of the month
        day.year++; // Increment the year
    }
    else if (day.day == days_in_month[day.month - 1]) { 
        // If it's the last day of the month
        day.month++; // Increment the month
        day.day = 1; // Set the day to the first day of the next month
    }
    else if (day.month == 2 && day.day == 29 && is_leap_year(day)) { 
        // If it's February 29 and it's a leap year
        day.day = 1; // Set the day to the first day of March
        day.month++; // Increment the month to March
    }
    else {
        day.day++; // Otherwise, just increment the day by 1
    }
    return day; // Return the new date
}

int main() {
    struct date today, tomorrow_date;
    printf("Enter a date (mm dd yyyy): ");
    scanf("%d %d %d", &today.month, &today.day, &today.year);
    tomorrow_date = tomorrow(today); // Get the date of the next day
    printf("Tomorrow's date is %d/%d/%.2d.\n", tomorrow_date.month, tomorrow_date.day, tomorrow_date.year % 100); // Print the date in the required format
    return 0;
}
